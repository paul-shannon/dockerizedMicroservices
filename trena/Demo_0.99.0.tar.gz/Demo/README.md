find out how to add an R package to rpy2 jupyter docker image
