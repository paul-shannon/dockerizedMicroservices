require(trena) || stop("unable to load trena Package")
BiocGenerics:::testPackage('trena')
