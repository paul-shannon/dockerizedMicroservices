require(MotifDb) || stop("unable to load MyPackage")
BiocGenerics:::testPackage('MotifDb')
