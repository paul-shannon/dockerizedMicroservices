rm (list=ls())
library (MotifDb)
sessionInfo ()
source ('unitTests/test_MotifDb.R')
run.tests ()

